import 'package:camera/camera.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:priti_app/widgets/home.dart';

List<CameraDescription> cameras;
CameraDescription camera;

void main() async {
  try {
    WidgetsFlutterBinding.ensureInitialized();
    await SystemChrome.setEnabledSystemUIOverlays([]);
    cameras = await availableCameras();
    camera = cameras[0];
    FirebaseApp app = await Firebase.initializeApp();
  } on CameraException catch (e) {
    print(e);
  }
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.

  final MaterialColor PrimaryColor = const MaterialColor(
    0xFFFFFFFF,
    const <int, Color>{
      50: const Color(0xFF6200EE),
      100: const Color(0xFF6200EE),
      200: const Color(0xFF6200EE),
      300: const Color(0xFF6200EE),
      400: const Color(0xFF6200EE),
      500: const Color(0xFF6200EE),
      600: const Color(0xFF6200EE),
      700: const Color(0xFF6200EE),
      800: const Color(0xFF6200EE),
      900: const Color(0xFF6200EE),
    },
  );

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: PrimaryColor,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      home: MyHomePage(),
    );
  }
}
