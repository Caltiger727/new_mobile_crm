class BCParseRegex {
  BCParseRegex() {
    init();
  }

  List<MapEntry<String, String>> zipRegexps = List();
  var addressKeywords = List();
  RegExp emailPattern = RegExp(
      r"(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|'(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*')@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\])");
  RegExp phonePattern = RegExp(r"[\+\(]?[1-9][0-9 .\-\(\)]{8,}[0-9]");

  RegExp urlPattern =
      RegExp(r'(?:(?:https?|ftp):\/\/)?[\w/\-?=%.]+\.[\w/\-?=%.]+');

  RegExp namePattern =
      RegExp(r"^[\w'\-,.][^0-9_!¡?÷?¿/\\+=@#$%ˆ&*(){}|~<>;:[\]]{2,}$");

  Map<String, dynamic> checkZipCode(String testData) {
    bool containsZip = false;
    var zipCode;

    List<MapEntry<String, String>> entries = zipRegexps;

    for (MapEntry<String, String> entry in entries) {
      containsZip = containsZip ||
          (RegExp(entry.value).hasMatch(testData) &&
              RegExp(entry.value).stringMatch(testData) != "");
      if (containsZip) {
        zipCode = RegExp(entry.value).stringMatch(testData);
        break;
      }
    }
    Map<String, dynamic> mapResult = Map();
    var _results = {
      'isZip': containsZip,
      'zipCode': zipCode,
    };
    mapResult.addAll(_results);
    return mapResult;
  }

  double checkLineForAddress(List<String> testdata) {
    bool containsZip = false;
    bool containsState = false;
    bool containsAddressKeyword = false;
    bool containsWord = false;
    bool containsCapitalizedWord = false;
    bool containsNumber = false;
    bool containsBuildingNum = false;
    for (String item in testdata) {
      List<MapEntry<String, String>> entries = zipRegexps;

      for (MapEntry<String, String> entry in entries) {
        containsZip = containsZip || RegExp(entry.value).hasMatch(item);
        if (containsZip) break;
      }

      containsState = containsState || RegExp("[A-Z]{2}").hasMatch(item);
      containsBuildingNum = containsBuildingNum || item.contains("/");
      containsWord = containsWord || RegExp("[A-Za-z]+").hasMatch(item);
      containsCapitalizedWord =
          containsCapitalizedWord || RegExp("[A-Z]+[a-z]+").hasMatch(item);
      for (String addressKeyword in addressKeywords) {
        containsAddressKeyword = containsAddressKeyword ||
            item.replaceAll(".", "").contains(addressKeyword);
      }
      containsNumber = containsNumber || RegExp("[0-9]+").hasMatch(item);
    }

    double addressProbability = 0;
    if (containsZip &&
        containsCapitalizedWord &&
        (containsState || containsAddressKeyword)) return 1.0;
    if (containsZip && containsWord) addressProbability = 0.5;
    if (containsCapitalizedWord) addressProbability += 0.1;
    if (containsAddressKeyword) addressProbability += 0.2;
    if (containsNumber) addressProbability += 0.05;
    if (containsBuildingNum) addressProbability += 0.05;
    if (testdata.length > 1) addressProbability += 0.05;
    if (testdata.length > 2) addressProbability += 0.05;
    return addressProbability;
  }

  void init() {
    zipRegexps.add(MapEntry("GB",
        "GIR[ ]?0AA|((AB|AL|B|BA|BB|BD|BH|BL|BN|BR|BS|BT|CA|CB|CF|CH|CM|CO|CR|CT|CV|CW|DA|DD|DE|DG|DH|DL|DN|DT|DY|E|EC|EH|EN|EX|FK|FY|G|GL|GY|GU|HA|HD|HG|HP|HR|HS|HU|HX|IG|IM|IP|IV|JE|KA|KT|KW|KY|L|LA|LD|LE|LL|LN|LS|LU|M|ME|MK|ML|N|NE|NG|NN|NP|NR|NW|OL|OX|PA|PE|PH|PL|PO|PR|RG|RH|RM|S|SA|SE|SG|SK|SL|SM|SN|SO|SP|SR|SS|ST|SW|SY|TA|TD|TF|TN|TQ|TR|TS|TW|UB|W|WA|WC|WD|WF|WN|WR|WS|WV|YO|ZE)(\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}))|BFPO[ ]?\\d{1,4}"));
    zipRegexps.add(MapEntry("JE", "JE\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}"));
    zipRegexps.add(MapEntry("GG", "GY\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}"));
    zipRegexps.add(MapEntry("IM", "IM\\d[\\dA-Z]?[ ]?\\d[ABD-HJLN-UW-Z]{2}"));
    zipRegexps.add(MapEntry("US", "\\d{5}([ \\-]\\d{4})?"));
    zipRegexps.add(MapEntry("CA",
        "[ABCEGHJKLMNPRSTVXY]\\d[ABCEGHJ-NPRSTV-Z][ ]?\\d[ABCEGHJ-NPRSTV-Z]\\d"));
    zipRegexps.add(MapEntry("IN", "\\d{6}"));
    zipRegexps.add(MapEntry("DE", "\\d{5}"));
    zipRegexps.add(MapEntry("JP", "\\d{3}-\\d{4}"));
    zipRegexps.add(MapEntry("FR", "\\d{2}[ ]?\\d{3}"));
    zipRegexps.add(MapEntry("AU", "\\d{4}"));
    zipRegexps.add(MapEntry("IT", "\\d{5}"));
    zipRegexps.add(MapEntry("CH", "\\d{4}"));
    zipRegexps.add(MapEntry("AT", "\\d{4}"));
    zipRegexps.add(MapEntry("ES", "\\d{5}"));
    zipRegexps.add(MapEntry("NL", "\\d{4}[ ]?[A-Z]{2}"));
    zipRegexps.add(MapEntry("BE", "\\d{4}"));
    zipRegexps.add(MapEntry("DK", "\\d{4}"));
    zipRegexps.add(MapEntry("SE", "\\d{3}[ ]?\\d{2}"));
    zipRegexps.add(MapEntry("NO", "\\d{4}"));
    zipRegexps.add(MapEntry("BR", "\\d{5}[\\-]?\\d{3}"));
    zipRegexps.add(MapEntry("PT", "\\d{4}([\\-]\\d{3})?"));
    zipRegexps.add(MapEntry("FI", "\\d{5}"));
    zipRegexps.add(MapEntry("AX", "22\\d{3}"));
    zipRegexps.add(MapEntry("KR", "\\d{3}[\\-]\\d{3}"));
    zipRegexps.add(MapEntry("CN", "\\d{6}"));
    zipRegexps.add(MapEntry("TW", "\\d{3}(\\d{2})?"));
    zipRegexps.add(MapEntry("SG", "\\d{6}"));
    zipRegexps.add(MapEntry("DZ", "\\d{5}"));
    zipRegexps.add(MapEntry("AD", "AD\\d{3}"));
    zipRegexps.add(MapEntry("AR", "([A-HJ-NP-Z])?\\d{4}([A-Z]{3})?"));
    zipRegexps.add(MapEntry("AM", "(37)?\\d{4}"));
    zipRegexps.add(MapEntry("AZ", "\\d{4}"));
    zipRegexps.add(MapEntry("BH", "((1[0-2]|[2-9])\\d{2})?"));
    zipRegexps.add(MapEntry("BD", "\\d{4}"));
    zipRegexps.add(MapEntry("BB", "(BB\\d{5})?"));
    zipRegexps.add(MapEntry("BY", "\\d{6}"));
    zipRegexps.add(MapEntry("BM", "[A-Z]{2}[ ]?[A-Z0-9]{2}"));
    zipRegexps.add(MapEntry("BA", "\\d{5}"));
    zipRegexps.add(MapEntry("IO", "BBND 1ZZ"));
    zipRegexps.add(MapEntry("BN", "[A-Z]{2}[ ]?\\d{4}"));
    zipRegexps.add(MapEntry("BG", "\\d{4}"));
    zipRegexps.add(MapEntry("KH", "\\d{5}"));
    zipRegexps.add(MapEntry("CV", "\\d{4}"));
    zipRegexps.add(MapEntry("CL", "\\d{7}"));
    zipRegexps.add(MapEntry("CR", "\\d{4,5}|\\d{3}-\\d{4}"));
    zipRegexps.add(MapEntry("HR", "\\d{5}"));
    zipRegexps.add(MapEntry("CY", "\\d{4}"));
    zipRegexps.add(MapEntry("CZ", "\\d{3}[ ]?\\d{2}"));
    zipRegexps.add(MapEntry("DO", "\\d{5}"));
    zipRegexps.add(MapEntry("EC", "([A-Z]\\d{4}[A-Z]|(?:[A-Z]{2})?\\d{6})?"));
    zipRegexps.add(MapEntry("EG", "\\d{5}"));
    zipRegexps.add(MapEntry("EE", "\\d{5}"));
    zipRegexps.add(MapEntry("FO", "\\d{3}"));
    zipRegexps.add(MapEntry("GE", "\\d{4}"));
    zipRegexps.add(MapEntry("GR", "\\d{3}[ ]?\\d{2}"));
    zipRegexps.add(MapEntry("GL", "39\\d{2}"));
    zipRegexps.add(MapEntry("GT", "\\d{5}"));
    zipRegexps.add(MapEntry("HT", "\\d{4}"));
    zipRegexps.add(MapEntry("HN", "(?:\\d{5})?"));
    zipRegexps.add(MapEntry("HU", "\\d{4}"));
    zipRegexps.add(MapEntry("IS", "\\d{3}"));
    zipRegexps.add(MapEntry("IN", "\\d{6}"));
    zipRegexps.add(MapEntry("ID", "\\d{5}"));
    zipRegexps.add(MapEntry("IL", "\\d{5}"));
    zipRegexps.add(MapEntry("JO", "\\d{5}"));
    zipRegexps.add(MapEntry("KZ", "\\d{6}"));
    zipRegexps.add(MapEntry("KE", "\\d{5}"));
    zipRegexps.add(MapEntry("KW", "\\d{5}"));
    zipRegexps.add(MapEntry("LA", "\\d{5}"));
    zipRegexps.add(MapEntry("LV", "\\d{4}"));
    zipRegexps.add(MapEntry("LB", "(\\d{4}([ ]?\\d{4})?)?"));
    zipRegexps.add(MapEntry("LI", "(948[5-9])|(949[0-7])"));
    zipRegexps.add(MapEntry("LT", "\\d{5}"));
    zipRegexps.add(MapEntry("LU", "\\d{4}"));
    zipRegexps.add(MapEntry("MK", "\\d{4}"));
    zipRegexps.add(MapEntry("MY", "\\d{5}"));
    zipRegexps.add(MapEntry("MV", "\\d{5}"));
    zipRegexps.add(MapEntry("MT", "[A-Z]{3}[ ]?\\d{2,4}"));
    zipRegexps.add(MapEntry("MU", "(\\d{3}[A-Z]{2}\\d{3})?"));
    zipRegexps.add(MapEntry("MX", "\\d{5}"));
    zipRegexps.add(MapEntry("MD", "\\d{4}"));
    zipRegexps.add(MapEntry("MC", "980\\d{2}"));
    zipRegexps.add(MapEntry("MA", "\\d{5}"));
    zipRegexps.add(MapEntry("NP", "\\d{5}"));
    zipRegexps.add(MapEntry("NZ", "\\d{4}"));
    zipRegexps.add(MapEntry("NI", "((\\d{4}-)?\\d{3}-\\d{3}(-\\d{1})?)?"));
    zipRegexps.add(MapEntry("NG", "(\\d{6})?"));
    zipRegexps.add(MapEntry("OM", "(PC )?\\d{3}"));
    zipRegexps.add(MapEntry("PK", "\\d{5}"));
    zipRegexps.add(MapEntry("PY", "\\d{4}"));
    zipRegexps.add(MapEntry("PH", "\\d{4}"));
    zipRegexps.add(MapEntry("PL", "\\d{2}-\\d{3}"));
    zipRegexps.add(MapEntry("PR", "00[679]\\d{2}([ \\-]\\d{4})?"));
    zipRegexps.add(MapEntry("RO", "\\d{6}"));
    zipRegexps.add(MapEntry("RU", "\\d{6}"));
    zipRegexps.add(MapEntry("SM", "4789\\d"));
    zipRegexps.add(MapEntry("SA", "\\d{5}"));
    zipRegexps.add(MapEntry("SN", "\\d{5}"));
    zipRegexps.add(MapEntry("SK", "\\d{3}[ ]?\\d{2}"));
    zipRegexps.add(MapEntry("SI", "\\d{4}"));
    zipRegexps.add(MapEntry("ZA", "\\d{4}"));
    zipRegexps.add(MapEntry("LK", "\\d{5}"));
    zipRegexps.add(MapEntry("TJ", "\\d{6}"));
    zipRegexps.add(MapEntry("TH", "\\d{5}"));
    zipRegexps.add(MapEntry("TN", "\\d{4}"));
    zipRegexps.add(MapEntry("TR", "\\d{5}"));
    zipRegexps.add(MapEntry("TM", "\\d{6}"));
    zipRegexps.add(MapEntry("UA", "\\d{5}"));
    zipRegexps.add(MapEntry("UY", "\\d{5}"));
    zipRegexps.add(MapEntry("UZ", "\\d{6}"));
    zipRegexps.add(MapEntry("VA", "00120"));
    zipRegexps.add(MapEntry("VE", "\\d{4}"));
    zipRegexps.add(MapEntry("ZM", "\\d{5}"));
    zipRegexps.add(MapEntry("AS", "96799"));
    zipRegexps.add(MapEntry("CC", "6799"));
    zipRegexps.add(MapEntry("CK", "\\d{4}"));
    zipRegexps.add(MapEntry("RS", "\\d{6}"));
    zipRegexps.add(MapEntry("ME", "8\\d{4}"));
    zipRegexps.add(MapEntry("CS", "\\d{5}"));
    zipRegexps.add(MapEntry("YU", "\\d{5}"));
    zipRegexps.add(MapEntry("CX", "6798"));
    zipRegexps.add(MapEntry("ET", "\\d{4}"));
    zipRegexps.add(MapEntry("FK", "FIQQ 1ZZ"));
    zipRegexps.add(MapEntry("NF", "2899"));
    zipRegexps.add(MapEntry("FM", "(9694[1-4])([ \\-]\\d{4})?"));
    zipRegexps.add(MapEntry("GF", "9[78]3\\d{2}"));
    zipRegexps.add(MapEntry("GN", "\\d{3}"));
    zipRegexps.add(MapEntry("GP", "9[78][01]\\d{2}"));
    zipRegexps.add(MapEntry("GS", "SIQQ 1ZZ"));
    zipRegexps.add(MapEntry("GU", "969[123]\\d([ \\-]\\d{4})?"));
    zipRegexps.add(MapEntry("GW", "\\d{4}"));
    zipRegexps.add(MapEntry("HM", "\\d{4}"));
    zipRegexps.add(MapEntry("IQ", "\\d{5}"));
    zipRegexps.add(MapEntry("KG", "\\d{6}"));
    zipRegexps.add(MapEntry("LR", "\\d{4}"));
    zipRegexps.add(MapEntry("LS", "\\d{3}"));
    zipRegexps.add(MapEntry("MG", "\\d{3}"));
    zipRegexps.add(MapEntry("MH", "969[67]\\d([ \\-]\\d{4})?"));
    zipRegexps.add(MapEntry("MN", "\\d{6}"));
    zipRegexps.add(MapEntry("MP", "9695[012]([ \\-]\\d{4})?"));
    zipRegexps.add(MapEntry("MQ", "9[78]2\\d{2}"));
    zipRegexps.add(MapEntry("NC", "988\\d{2}"));
    zipRegexps.add(MapEntry("NE", "\\d{4}"));
    zipRegexps.add(MapEntry("VI", "008(([0-4]\\d)|(5[01]))([ \\-]\\d{4})?"));
    zipRegexps.add(MapEntry("PF", "987\\d{2}"));
    zipRegexps.add(MapEntry("PG", "\\d{3}"));
    zipRegexps.add(MapEntry("PM", "9[78]5\\d{2}"));
    zipRegexps.add(MapEntry("PN", "PCRN 1ZZ"));
    zipRegexps.add(MapEntry("PW", "96940"));
    zipRegexps.add(MapEntry("RE", "9[78]4\\d{2}"));
    zipRegexps.add(MapEntry("SH", "(ASCN|STHL) 1ZZ"));
    zipRegexps.add(MapEntry("SJ", "\\d{4}"));
    zipRegexps.add(MapEntry("SO", "\\d{5}"));
    zipRegexps.add(MapEntry("SZ", "[HLMS]\\d{3}"));
    zipRegexps.add(MapEntry("TC", "TKCA 1ZZ"));
    zipRegexps.add(MapEntry("WF", "986\\d{2}"));
    zipRegexps.add(MapEntry("XK", "\\d{5}"));
    zipRegexps.add(MapEntry("YT", "976\\d{2}"));

    addressKeywords.add("blvd");
    addressKeywords.add("st");
    addressKeywords.add("street");
    addressKeywords.add("lane");
    addressKeywords.add("plot");
    addressKeywords.add('house');
    addressKeywords.add("building");
  }
}
