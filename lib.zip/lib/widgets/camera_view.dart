import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
import 'package:path_provider/path_provider.dart';
import 'package:priti_app/widgets/home.dart';
import 'package:priti_app/widgets/ocr_image.dart';
import 'dart:ui' as ui;

import '../main.dart';

class CameraView extends StatefulWidget {
  final StringCallback onCardSave;
  final bool isReceipt;

  CameraView(this.isReceipt, {this.onCardSave});

  @override
  _CameraViewState createState() => _CameraViewState(isReceipt);
}

class _CameraViewState extends State<CameraView> {
  CameraController controller;
  bool isReceipt = false;
  bool isImageCaptured = false;
  File imgFile;
  String imagePath;
  final bool isReceipt1;

  _CameraViewState(this.isReceipt1);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    isReceipt = isReceipt1;
    initCamera();
  }

  @override
  void dispose() {
    // TODO: implement dispose
    controller?.dispose();
    super.dispose();
  }

  set onCardSaved(int position) {
    widget.onCardSave();
  }

  void initCamera() async {
    controller = CameraController(camera, ResolutionPreset.ultraHigh);
    controller.initialize().then((_) {
      if (!mounted) {
        return;
      }
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final deviceRatio = size.width / size.height;
    return controller != null && controller.value.isInitialized
        ? OrientationBuilder(
            builder: (context, orientation) {
              if (orientation == Orientation.portrait) {
                print(orientation);
              } else {
                print(orientation);
              }
              return Container(
                height: MediaQuery.of(context).size.height,
                width: MediaQuery.of(context).size.width,
                color: Color.fromRGBO(00, 00, 00, 0.9),
                child: Stack(
                  children: [
                    !isImageCaptured
                        ? Transform.scale(
                            scale: isReceipt
                                ? controller.value.aspectRatio / deviceRatio
                                : 3 / 4,
                            child: Center(
                              child: AspectRatio(
                                  aspectRatio: controller.value.aspectRatio,
                                  child: CameraPreview(controller)),
                            ))
                        : imgFile != null
                            ? Container(
                                height: MediaQuery.of(context).size.height,
                                width: MediaQuery.of(context).size.width,
                                child: Image.file(
                                  imgFile,
                                ),
                              )
                            : SizedBox(),
                    Positioned(
                      bottom: 0.0,
                      left: 0.0,
                      child: Container(
                        height: 120.0,
                        width: MediaQuery.of(context).size.width,
                        color: Color.fromRGBO(00, 00, 00, 0.7),
                        child: Container(
                          padding: EdgeInsets.all(20.0),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              GestureDetector(
                                  onTap: () {
                                    if (!isImageCaptured)
                                      Navigator.of(context).pop();
                                    if (mounted)
                                      setState(() {
                                        isImageCaptured = !isImageCaptured;
                                      });
                                  },
                                  child: Container(
                                      width: 50.0,
                                      height: 50.0,
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.all(
                                            Radius.circular(25.0)),
                                      ),
                                      child: Icon(
                                          isImageCaptured
                                              ? Icons.close
                                              : Icons.arrow_back,
                                          size: 20.0,
                                          color: Colors.red))),
                              !isImageCaptured
                                  ? GestureDetector(
                                      onTap: () {
                                        capture();
                                      },
                                      child: Container(
                                          width: 60.0,
                                          height: 60.0,
                                          decoration: BoxDecoration(
                                            color: Colors.white,
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(30.0)),
                                          ),
                                          child: Icon(
                                              Platform.isIOS
                                                  ? Icons.camera
                                                  : Icons.camera_alt_outlined,
                                              size: 40.0,
                                              color: Colors.red)))
                                  : SizedBox(),
                              isImageCaptured
                                  ? GestureDetector(
                                      onTap: () {
                                        bool val = false;
                                        if (isImageCaptured) {
                                          val = true;
                                          gotoNext();
                                        }
                                        if (mounted)
                                          setState(() {
                                            isImageCaptured = val;
                                          });
                                      },
                                      child: Container(
                                        width: 50.0,
                                        height: 50.0,
                                        padding: EdgeInsets.all(10.9),
                                        decoration: BoxDecoration(
                                          color: Colors.white,
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(30.0)),
                                        ),
                                        child: Icon(Icons.check,
                                            size: 20.0, color: Colors.red),
                                      ),
                                    )
                                  : SizedBox(
                                      width: 60.0,
                                    )
                            ],
                          ),
                        ),
                      ),
                    ),
                    !isReceipt
                        ? Positioned(
                            top: 0.0,
                            left: 0.0,
                            child: Container(
                              height: 120.0,
                              width: MediaQuery.of(context).size.width,
                              color: Color.fromRGBO(00, 00, 00, 0.7),
                            ))
                        : SizedBox(),
                    !isReceipt
                        ? Positioned(
                            top: 120.0,
                            bottom: 120.0,
                            left: 0.0,
                            child: Container(
                              height: MediaQuery.of(context).size.height,
                              width: 20.0,
                              color: Color.fromRGBO(00, 00, 00, 0.7),
                            ))
                        : SizedBox(),
                    !isReceipt
                        ? Positioned(
                            top: 120.0,
                            bottom: 120.0,
                            right: 0.0,
                            child: Container(
                              height: MediaQuery.of(context).size.height,
                              width: 20.0,
                              color: Color.fromRGBO(00, 00, 00, 0.7),
                            ))
                        : SizedBox(),
                  ],
                ),
              );
            },
          )
        : SizedBox();
  }

  void gotoNext() {

      Navigator.pushReplacement(
          context,
          PageTransition(
              type: PageTransitionType.rightToLeft,
              child: ScanOCRImage(
                imagePath,
                false,
                onCardSave: () => onCardSaved = 0,
              )));
      /*Navigator.pushReplacement(
              context,
              PageTransition(
                  type: PageTransitionType.rightToLeft,
                  child: CropPage(
                      title: 'crop',
                      image: image,
                      imageInfo: new ImageInfo(image: image, scale: 1.0))));*/

  }

  String timestamp() => new DateTime.now().millisecondsSinceEpoch.toString();

  Future<String> capture() async {
    if (!controller.value.isInitialized) {
      return null;
    }
    final Directory extDir = await getApplicationDocumentsDirectory();
    final String dirPath = '${extDir.path}/Pictures/priti';
    await new Directory(dirPath).create(recursive: true);
    final String filePath = '$dirPath/${timestamp()}.png';

    try {
      XFile xFile = await controller.takePicture();
      xFile.saveTo(filePath);
      try {
        File imageFile = new File(xFile.path);
        if (mounted)
          setState(() {
            imgFile = imageFile;
            isImageCaptured = true;
            imagePath = filePath;
          });
        _loadImage(imageFile).then((image) {});
      } catch (e) {
        print(e);
      }
    } on CameraException catch (e) {
      return null;
    }
    return filePath;
  }

  Future<ui.Image> _loadImage(File img) async {
    if (img != null) {
      var codec = await ui.instantiateImageCodec(img.readAsBytesSync());
      var frame = await codec.getNextFrame();
      return frame.image;
    }
    return null;
  }
}
