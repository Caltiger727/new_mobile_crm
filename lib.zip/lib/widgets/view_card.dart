import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:full_screen_image/full_screen_image.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:page_transition/page_transition.dart';
import 'package:priti_app/data/card_data.dart';
import 'package:priti_app/widgets/home.dart';
import 'package:priti_app/widgets/ocr_image.dart';
import 'package:url_launcher/url_launcher.dart';

class ViewCard extends StatefulWidget {
  final CardsInfo cardItem;
  final StringCallback onCardSave;

  ViewCard(this.cardItem, {this.onCardSave});

  @override
  _ViewCardState createState() => _ViewCardState(cardItem);
}

class _ViewCardState extends State<ViewCard> {
  final CardsInfo cardItem;

  _ViewCardState(this.cardItem);

  set onCardSaved(int position) {
    widget.onCardSave();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      child: SafeArea(
        child: Column(
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () => Navigator.of(context).pop(),
                    child: Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                    ),
                  ),
                  Text(
                    'Card Details',
                    style: GoogleFonts.glegoo(
                      textStyle: TextStyle(color: Colors.black, fontSize: 20),
                    ),
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        onTap: () {
                          Navigator.pushReplacement(
                              context,
                              PageTransition(
                                  type: PageTransitionType.rightToLeft,
                                  child: ScanOCRImage("", true,
                                      cardItem: cardItem,
                                      onCardSave: () => onCardSaved = 0)));
                        },
                        child: Icon(
                          Icons.edit,
                          color: Colors.black,
                          size: 30.0,
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            Expanded(
                child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.center,
                    child: cardItem.imagePathColumn.contains("https") ||
                            cardItem.imagePathColumn.contains("http")
                        ? Padding(
                            padding:
                                const EdgeInsets.only(left: 20.0, right: 20.0),
                            child: FullScreenWidget(
                              child: Hero(
                                tag: cardItem.idColumn,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(16),
                                  child: CachedNetworkImage(
                                    imageUrl: cardItem.imagePathColumn,
                                    placeholder: (context, url) => Center(
                                        child: CircularProgressIndicator()),
                                    errorWidget: (context, url, error) =>
                                        Icon(Icons.error),
                                  ),
                                ),
                              ),
                            ),
                          )
                        : Image.file(
                            File(cardItem.imagePathColumn),
                            width: MediaQuery.of(context).size.width - 100.0,
                            height: 150.0,
                          ),
                  ),
                  Container(
                      padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 5.0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("Personal Details",
                            style: GoogleFonts.glegoo(
                              textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: 18.0,
                                fontFamily: "Netflix",
                                fontWeight: FontWeight.bold,
                              ),
                            )),
                      )),
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 5.0),
                    child: Text("Name:- " + getText(cardItem.nameColumn),
                        style: GoogleFonts.glegoo(
                          textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 15.0,
                            fontFamily: "Netflix",
                            fontWeight: FontWeight.w600,
                          ),
                        )),
                  ),
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 5.0),
                    child: Row(
                      children: [
                        Text("Phone:- ",
                            style: GoogleFonts.glegoo(
                              textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: 15.0,
                                fontFamily: "Netflix",
                                fontWeight: FontWeight.w600,
                              ),
                            )),
                        GestureDetector(
                          behavior: HitTestBehavior.translucent,
                          onTap: () {
                            _launchURL(cardItem.phoneColumn, false);
                          },
                          child: Text(getText(cardItem.phoneColumn),
                              style: GoogleFonts.glegoo(
                                textStyle: TextStyle(
                                  color: cardItem.phoneColumn != "" &&
                                          cardItem.phoneColumn.toLowerCase() !=
                                              "na"
                                      ? Colors.blueAccent
                                      : Colors.black,
                                  fontSize: 15.0,
                                  fontFamily: "Netflix",
                                  fontWeight: FontWeight.w600,
                                ),
                              )),
                        ),
                      ],
                    ),
                  ),
                  cardItem.phoneColumn2.length > 0
                      ? Container(
                          padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 5.0),
                          child: Row(
                            children: [
                              Text("Phone:- ",
                                  style: GoogleFonts.glegoo(
                                    textStyle: TextStyle(
                                      color: Colors.black,
                                      fontSize: 15.0,
                                      fontFamily: "Netflix",
                                      fontWeight: FontWeight.w600,
                                    ),
                                  )),
                              GestureDetector(
                                behavior: HitTestBehavior.translucent,
                                onTap: () {
                                  _launchURL(cardItem.phoneColumn2, false);
                                },
                                child: Text(getText(cardItem.phoneColumn2),
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                        color: cardItem.phoneColumn2 != "" &&
                                                cardItem.phoneColumn2
                                                        .toLowerCase() !=
                                                    "na"
                                            ? Colors.blueAccent
                                            : Colors.black,
                                        fontSize: 15.0,
                                        fontFamily: "Netflix",
                                        fontWeight: FontWeight.w600,
                                      ),
                                    )),
                              ),
                            ],
                          ),
                        )
                      : SizedBox(),
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 5.0),
                    child: Row(
                      children: [
                        Text("Email:- ",
                            style: GoogleFonts.glegoo(
                              textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: 15.0,
                                fontFamily: "Netflix",
                                fontWeight: FontWeight.w600,
                              ),
                            )),
                        GestureDetector(
                          behavior: HitTestBehavior.translucent,
                          onTap: () {
                            _launchURL(cardItem.emailColumn, true);
                          },
                          child: Text(getText(cardItem.emailColumn),
                              style: GoogleFonts.glegoo(
                                textStyle: TextStyle(
                                  color: cardItem.emailColumn != "" &&
                                          cardItem.emailColumn.toLowerCase() !=
                                              "na"
                                      ? Colors.blueAccent
                                      : Colors.black,
                                  fontSize: 15.0,
                                  fontFamily: "Netflix",
                                  fontWeight: FontWeight.w600,
                                ),
                              )),
                        ),
                      ],
                    ),
                  ),
                  cardItem.emailColumn2.length > 0
                      ? Container(
                          padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 5.0),
                          child: Row(
                            children: [
                              Text("Email:- ",
                                  style: GoogleFonts.glegoo(
                                    textStyle: TextStyle(
                                      color: Colors.black,
                                      fontSize: 15.0,
                                      fontFamily: "Netflix",
                                      fontWeight: FontWeight.w600,
                                    ),
                                  )),
                              GestureDetector(
                                behavior: HitTestBehavior.translucent,
                                onTap: () {
                                  _launchURL(cardItem.emailColumn2, true);
                                },
                                child: Text(getText(cardItem.emailColumn2),
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                        color: cardItem.emailColumn2 != "" &&
                                                cardItem.emailColumn2
                                                        .toLowerCase() !=
                                                    "na"
                                            ? Colors.blueAccent
                                            : Colors.black,
                                        fontSize: 15.0,
                                        fontFamily: "Netflix",
                                        fontWeight: FontWeight.w600,
                                      ),
                                    )),
                              ),
                            ],
                          ),
                        )
                      : SizedBox(),
                  SizedBox(
                    height: 20.0,
                  ),
                  Container(
                      padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 5.0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("Address Details",
                            style: GoogleFonts.glegoo(
                              textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: 18.0,
                                fontFamily: "Netflix",
                                fontWeight: FontWeight.bold,
                              ),
                            )),
                      )),
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                    child: Text("Address:- " + getText(cardItem.addressColumn),
                        style: GoogleFonts.glegoo(
                          textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 15.0,
                            fontFamily: "Netflix",
                            fontWeight: FontWeight.w600,
                          ),
                        )),
                  ),
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                    child: Text("Zip Code:- " + getText(cardItem.zipColumn),
                        style: GoogleFonts.glegoo(
                          textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 15.0,
                            fontFamily: "Netflix",
                            fontWeight: FontWeight.w600,
                          ),
                        )),
                  ),
                  SizedBox(
                    height: 20.0,
                  ),
                  Container(
                      padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 5.0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("Professional Details",
                            style: GoogleFonts.glegoo(
                              textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: 18.0,
                                fontFamily: "Netflix",
                                fontWeight: FontWeight.bold,
                              ),
                            )),
                      )),
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                    child: Text("Company:- " + getText(cardItem.companyColumn),
                        style: GoogleFonts.glegoo(
                          textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 15.0,
                            fontFamily: "Netflix",
                            fontWeight: FontWeight.w600,
                          ),
                        )),
                  ),
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                    child: Text("Job Title:- " + getText(cardItem.jobColumn),
                        style: GoogleFonts.glegoo(
                          textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 15.0,
                            fontFamily: "Netflix",
                            fontWeight: FontWeight.w600,
                          ),
                        )),
                  ),
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                    child: Row(
                      children: [
                        Text("Website:- ",
                            style: GoogleFonts.glegoo(
                              textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: 15.0,
                                fontFamily: "Netflix",
                                fontWeight: FontWeight.w600,
                              ),
                            )),
                        GestureDetector(
                          behavior: HitTestBehavior.translucent,
                          onTap: () {
                            _launchURL(cardItem.urlColumn, false, isWeb: true);
                          },
                          child: Text(getText(cardItem.urlColumn),
                              style: GoogleFonts.glegoo(
                                textStyle: TextStyle(
                                  color: cardItem.urlColumn != "" &&
                                          cardItem.urlColumn.toLowerCase() !=
                                              "na"
                                      ? Colors.blueAccent
                                      : Colors.black,
                                  fontSize: 15.0,
                                  fontFamily: "Netflix",
                                  fontWeight: FontWeight.w600,
                                ),
                              )),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(
                    height: 20.0,
                  ),
                  Container(
                      padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 5.0),
                      child: Align(
                        alignment: Alignment.centerLeft,
                        child: Text("Notes",
                            style: GoogleFonts.glegoo(
                              textStyle: TextStyle(
                                color: Colors.black,
                                fontSize: 18.0,
                                fontFamily: "Netflix",
                                fontWeight: FontWeight.bold,
                              ),
                            )),
                      )),
                  Container(
                    padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                    child: Text("Notes:- " + getText(cardItem.noteColumn),
                        style: GoogleFonts.glegoo(
                          textStyle: TextStyle(
                            color: Colors.black,
                            fontSize: 15.0,
                            fontFamily: "Netflix",
                            fontWeight: FontWeight.w600,
                          ),
                        )),
                  ),
                ],
              ),
            ))
          ],
        ),
      ),
    ));
  }

  String getText(String text) {
    if (text == null || text == "") {
      return "NA";
    } else {
      return text;
    }
  }

  void _launchURL(String text, isEmail, {bool isWeb}) async {
    if (text == null || text.toLowerCase() == 'na' || text == "") {
      return;
    }
    Uri _schemeLaunchUri;
    if (isEmail) {
      _schemeLaunchUri = Uri(
          scheme: 'mailto',
          path: text,
          queryParameters: {'subject': 'Priti BCR'});
    } else {
      if (isWeb != null && isWeb == true) {
        _schemeLaunchUri = Uri(
          scheme: "http",
          path: text,
        );
      } else {
        _schemeLaunchUri = Uri(
          scheme: 'tel',
          path: text,
        );
      }
    }
    String url = _schemeLaunchUri.toString();

    if (await canLaunch(url)) {
      await launch(url);
    } else {
      // print('Could not launch $url');
    }
  }
}
