import 'dart:async';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:page_transition/page_transition.dart';
import 'package:priti_app/data/card_data.dart';
import 'package:priti_app/data/database_helper.dart';
import 'package:priti_app/widgets/ocr_image.dart';
import 'package:priti_app/widgets/view_card.dart';

class MyAllCards extends StatefulWidget {
  final List<CardsInfo> cardsList;

  MyAllCards(this.cardsList);

  @override
  _MyAllCardsState createState() => _MyAllCardsState(cardsList);
}

class _MyAllCardsState extends State<MyAllCards> {
  List<CardsInfo> cardsList;
  var _searchQuery = TextEditingController();
  Timer _debounce;
  List<CardsInfo> duplicateCards;
  var db = DatabaseHelper();

  _MyAllCardsState(this.cardsList);

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    duplicateCards = cardsList;
    _searchQuery.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _searchQuery.removeListener(_onSearchChanged);
    _searchQuery.dispose();
    if (_debounce != null) _debounce.cancel();
  }

  _onSearchChanged() {
    if (_debounce?.isActive ?? false) _debounce.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      if (_searchQuery.text == '') {
        cardsList = new List();
        cardsList = duplicateCards;
      } else {
        cardsList = new List();
        for (int i = 0; i < duplicateCards.length; i++) {
          String cardName = duplicateCards[i].nameColumn;
          String cardEmail = duplicateCards[i].emailColumn;
          String cardPhone = duplicateCards[i].phoneColumn;
          if (cardName
                  .toLowerCase()
                  .contains(_searchQuery.text.toLowerCase()) ||
              cardEmail
                  .toLowerCase()
                  .contains(_searchQuery.text.toLowerCase()) ||
              cardPhone
                  .toLowerCase()
                  .contains(_searchQuery.text.toLowerCase())) {
            cardsList.add(duplicateCards[i]);
          }
        }
        if (mounted) setState(() {});
      }
      if (mounted) setState(() {});
    });
  }

  set onCardSaved(int position) {}

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
            height: MediaQuery.of(context).size.height,
            width: MediaQuery.of(context).size.width,
            child: SafeArea(
              child: Column(
                children: [
                  Container(
                      padding: EdgeInsets.fromLTRB(15.0, 15.0, 15.0, 15.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTap: () => Navigator.of(context).pop(),
                            child: Icon(
                              Icons.arrow_back,
                              color: Colors.black,
                            ),
                          ),
                          Text(
                            'All Cards',
                            style: GoogleFonts.glegoo(
                              textStyle:
                                  TextStyle(color: Colors.black, fontSize: 20),
                            ),
                          ),
                          SizedBox(
                            width: 30.0,
                          )
                        ],
                      )),
                  Expanded(
                      child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Container(
                        width: MediaQuery.of(context).size.width,
                        height: 1.0,
                        color: Colors.black45,
                      ),
                      Container(
                        height: 60,
                        margin: EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 20.0),
                        decoration: BoxDecoration(
                          borderRadius: const BorderRadius.all(
                            Radius.circular(25.0),
                          ),
                          border: Border.all(width: 1, color: Colors.black),
                        ),
                        child: TextFormField(
                            style: GoogleFonts.glegoo(
                              textStyle:
                                  TextStyle(color: Colors.black, fontSize: 20),
                            ),
                            controller: _searchQuery,
                            decoration: InputDecoration(
                                border: InputBorder.none,
                                hintText: 'Search',
                                contentPadding: EdgeInsets.only(
                                    left: 15.0, right: 20.0, top: 10.0),
                                hintStyle: GoogleFonts.glegoo(
                                  textStyle: TextStyle(
                                      color: Colors.black, fontSize: 20),
                                ),
                                suffixIcon: Icon(FontAwesomeIcons.search))),
                      ),
                      cardsList != null && cardsList.length > 0
                          ? Expanded(
                              child: ListView.builder(
                                itemCount: cardsList.length,
                                shrinkWrap: true,
                                itemBuilder: (BuildContext context, int index) {
                                  return GestureDetector(
                                    onTap: () {
                                      Navigator.push(
                                          context,
                                          PageTransition(
                                              type: PageTransitionType
                                                  .rightToLeft,
                                              child: ViewCard(cardsList[index],
                                                  onCardSave: () => setState(
                                                        () => onCardSaved = 0,
                                                      ))));
                                    },
                                    child: Container(
                                        margin: EdgeInsets.fromLTRB(
                                            15.0, 10.0, 15.0, 20.0),
                                        child: Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                          children: [
                                            Expanded(
                                              flex: 1,
                                              child: cardsList[index]
                                                          .imagePathColumn
                                                          .contains("https") ||
                                                      cardsList[index]
                                                          .imagePathColumn
                                                          .contains("http")
                                                  ? CachedNetworkImage(
                                                      imageUrl: cardsList[index]
                                                          .imagePathColumn,
                                                      placeholder: (context,
                                                              url) =>
                                                          Center(
                                                              child:
                                                                  CircularProgressIndicator()),
                                                      errorWidget: (context,
                                                              url, error) =>
                                                          Icon(Icons.error),
                                                      width: 100.0,
                                                      height: 70.0,
                                                    )
                                                  : Image.file(
                                                      File(cardsList[index]
                                                          .imagePathColumn),
                                                      width: 100.0,
                                                      height: 70.0,
                                                    ),
                                            ),
                                            SizedBox(
                                              width: 10.0,
                                            ),
                                            Expanded(
                                              flex: 2,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Text(
                                                      cardsList[index]
                                                          .nameColumn,
                                                      maxLines: 1,
                                                      textAlign:
                                                          TextAlign.start,
                                                      overflow:
                                                          TextOverflow.ellipsis,
                                                      style: GoogleFonts.glegoo(
                                                        textStyle: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 15.0,
                                                          fontFamily: "Netflix",
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                                      )),
                                                  Text(
                                                      cardsList[index]
                                                          .phoneColumn,
                                                      textAlign:
                                                          TextAlign.start,
                                                      style: GoogleFonts.glegoo(
                                                        textStyle: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 15.0,
                                                          fontFamily: "Netflix",
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            ),
                                            Expanded(
                                              flex: 1,
                                              child: Column(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.end,
                                                children: [
                                                  PopupMenuButton(
                                                    itemBuilder: (context) {
                                                      return <PopupMenuItem>[
                                                        PopupMenuItem(
                                                            child:
                                                                GestureDetector(
                                                                    behavior:
                                                                        HitTestBehavior
                                                                            .translucent,
                                                                    onTap: () {
                                                                      Navigator.push(
                                                                          context,
                                                                          PageTransition(
                                                                              type: PageTransitionType.rightToLeft,
                                                                              child: ScanOCRImage("", true,
                                                                                  cardItem: cardsList[index],
                                                                                  onCardSave: () => setState(
                                                                                        () => onCardSaved = 0,
                                                                                      ))));
                                                                    },
                                                                    child: Text(
                                                                        "Edit"))),
                                                        PopupMenuItem(
                                                            child:
                                                                GestureDetector(
                                                          behavior:
                                                              HitTestBehavior
                                                                  .translucent,
                                                          onTap: () {
                                                            Navigator.of(
                                                                    context)
                                                                .pop();
                                                            showDialog(
                                                                context:
                                                                    context,
                                                                barrierDismissible:
                                                                    false,
                                                                builder: (_) {
                                                                  return deleteCardDialog(
                                                                      context,
                                                                      index,
                                                                      cardsList[
                                                                              index]
                                                                          .idColumn);
                                                                });
                                                          },
                                                          child: Text("Delete"),
                                                        ))
                                                      ];
                                                    },
                                                    child: Icon(
                                                      Icons.more_vert,
                                                      color: Colors.black,
                                                    ),
                                                  ),
                                                  Text(
                                                      getDate(cardsList[index]
                                                          .dateColumn),
                                                      style: GoogleFonts.glegoo(
                                                        textStyle: TextStyle(
                                                          color: Colors.black,
                                                          fontSize: 12.0,
                                                          fontFamily: "Netflix",
                                                          fontWeight:
                                                              FontWeight.w600,
                                                        ),
                                                      ))
                                                ],
                                              ),
                                            )
                                          ],
                                        )),
                                  );
                                },
                              ),
                            )
                          : Center(
                              child: Text('No Contacts',
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.glegoo(
                                    textStyle: TextStyle(
                                      color: Colors.black,
                                      fontSize: 17.0,
                                      fontFamily: "Netflix",
                                      fontWeight: FontWeight.w600,
                                    ),
                                  )),
                            )
                    ],
                  ))
                ],
              ),
            )));
  }

  deleteCardDialog(BuildContext context, int position, String cardID) {
    print("delete");
    return Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      child: Wrap(
        children: [
          Container(
            width: 300,
            margin: EdgeInsets.only(
                left: 10.0, right: 10.0, top: 25.0, bottom: 25.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Text(
                      'Delete Card!',
                      style: TextStyle(color: Colors.black, fontSize: 20.0),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context, rootNavigator: true).pop();
                      },
                      child: Icon(Icons.close),
                    )
                  ],
                ),
                SizedBox(
                  height: 10,
                ),
                SizedBox(
                  height: 15.0,
                  child: new Center(
                    child: new Container(
                      margin:
                          new EdgeInsetsDirectional.only(start: 1.0, end: 1.0),
                      height: 1.0,
                      color: Colors.grey,
                    ),
                  ),
                ),
                Container(
                  padding:
                      EdgeInsets.symmetric(vertical: 6.0, horizontal: 12.0),
                  child: Text(
                    'Are you sure you want to delete this card? Deleted card is not recoverable.',
                    style: TextStyle(fontSize: 17.0),
                  ),
                ),
                SizedBox(
                  height: 15.0,
                  child: new Center(
                    child: new Container(
                      margin:
                          new EdgeInsetsDirectional.only(start: 1.0, end: 1.0),
                      height: 1.0,
                      color: Colors.grey,
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(),
                    Row(
                      children: <Widget>[
                        InkWell(
                          onTap: () {
                            Navigator.of(context, rootNavigator: true).pop();
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 12.0),
                            decoration: BoxDecoration(
                                color: Color(0xFF99A1AE),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(8.0))),
                            child: Center(
                              child: Text(
                                'Close',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(
                          width: 8.0,
                        ),
                        InkWell(
                          onTap: () {
                            Navigator.of(context, rootNavigator: true).pop();
                            deleteCard(position, cardID);
                          },
                          child: Container(
                            padding: EdgeInsets.symmetric(
                                vertical: 10.0, horizontal: 12.0),
                            decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.blue,
                                    Colors.blueAccent,
                                  ],
                                  begin: Alignment.centerRight,
                                  end: Alignment.centerLeft,
                                ),
                                borderRadius: const BorderRadius.all(
                                  Radius.circular(8.0),
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.4),
                                    spreadRadius: 4,
                                    blurRadius: 10,
                                    offset: Offset(0, 3),
                                  )
                                ]),
                            child: Center(
                              child: Text(
                                'Yes, delete',
                                style: TextStyle(
                                    color: Colors.white, fontSize: 16),
                              ),
                            ),
                          ),
                        )
                      ],
                    )
                  ],
                ),
              ],
            ),
          )
        ],
      ),
    );
  }

  void deleteCard(int position, String cardID) async {
    int val = await db.deletePath(cardID);
    if (val > 0) {
      cardsList.removeAt(position);
      if (mounted) setState(() {});
    }
    if (FirebaseAuth.instance.currentUser != null)
      FirebaseFirestore.instance
          .collection('MyCards')
          .doc(FirebaseAuth.instance.currentUser.uid)
          .collection('Cards')
          .doc(cardID)
          .delete();
  }

  String getDate(String dateTimeString) {
    DateFormat format = DateFormat("MM/dd/yyyy");
    final DateTime dateTime = DateTime.parse(dateTimeString);
    String formattedDate = format.format(dateTime);
    return formattedDate;
  }
}
