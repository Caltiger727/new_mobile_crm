import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:camera/camera.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart' as firebase_storage;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:google_fonts/google_fonts.dart';

import 'package:image_gallery_saver/image_gallery_saver.dart';
import 'package:intl/intl.dart';
import 'package:page_transition/page_transition.dart';
import 'package:path_provider/path_provider.dart';
import 'package:priti_app/data/card_data.dart';
import 'package:priti_app/data/database_helper.dart';
import 'package:priti_app/services/auth.dart';
import 'package:priti_app/services/google_auth.dart';
import 'package:priti_app/widgets/all_cards.dart';
import 'package:priti_app/widgets/camera_view.dart';

import 'package:permission_handler/permission_handler.dart' as PH;
import 'package:googleapis/sheets/v4.dart' as sheets;

import 'dart:ui' as ui;

import '../main.dart';

class MyHomePage extends StatefulWidget {
  MyHomePage({Key key}) : super(key: key);

  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> with TickerProviderStateMixin {
  File val;
  var db = DatabaseHelper();
  List<CardsInfo> cardsList = List();

  var _searchQuery = TextEditingController();
  Timer _debounce;
  List<CardsInfo> duplicateCards;
  DocumentSnapshot userDoc;
  bool isLogging = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _getSavedCardFromLocale();
    getCurrentUser();
    _searchQuery.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    _searchQuery.removeListener(_onSearchChanged);
    _searchQuery.dispose();
    if (_debounce != null) _debounce.cancel();
  }

  _onSearchChanged() {
    if (_debounce?.isActive ?? false) _debounce.cancel();
    _debounce = Timer(const Duration(milliseconds: 500), () {
      if (_searchQuery.text == '') {
        cardsList = new List();
        cardsList = duplicateCards;
      } else {
        cardsList = new List();
        for (int i = 0; i < duplicateCards.length; i++) {
          String cardName = duplicateCards[i].nameColumn;
          String cardEmail = duplicateCards[i].emailColumn;
          String cardPhone = duplicateCards[i].phoneColumn;
          if (cardName
                  .toLowerCase()
                  .contains(_searchQuery.text.toLowerCase()) ||
              cardEmail
                  .toLowerCase()
                  .contains(_searchQuery.text.toLowerCase()) ||
              cardPhone
                  .toLowerCase()
                  .contains(_searchQuery.text.toLowerCase())) {
            cardsList.add(duplicateCards[i]);
          }
        }
        if (mounted) setState(() {});
      }

      if (mounted) setState(() {});
    });
  }

  Widget tabHintText(text) => Text(text,
      textAlign: TextAlign.center,
      style: GoogleFonts.glegoo(
          textStyle: TextStyle(
        color: Colors.white,
        fontSize: 20.0,
        fontFamily: "Netflix",
        fontWeight: FontWeight.w500,
      )));

  Future<void> _getSavedCardFromLocale() async {
    cardsList = await db.getAllCards();
    duplicateCards = cardsList;
    //print(cardsList.length);
    if (mounted) setState(() {});
  }

  set onCardSaved(int position) {
    _getSavedCardFromLocale();
  }

  Future<void> getCurrentUser() async {
    if (FirebaseAuth.instance.currentUser != null) {
      userDoc = await FirebaseFirestore.instance
          .collection('Users')
          .doc(FirebaseAuth.instance.currentUser.uid)
          .get();
      syncWithLocaleDB();
    }
    if (mounted) setState(() {});
  }

  _handleSignIn() async {
    if (mounted) {
      setState(() {
        isLogging = true;
      });
    }
    if (FirebaseAuth.instance.currentUser == null) {
      try {
        User user = await Auth().googleLogin();
        if (user != null) {
          registerNewUser(user);
        } else {
          if (mounted) {
            setState(() {
              isLogging = false;
            });
          }
          Fluttertoast.showToast(
              msg: "Something went wrong please try again later",
              toastLength: Toast.LENGTH_LONG,
              gravity: ToastGravity.CENTER,
              timeInSecForIosWeb: 1,
              backgroundColor: Colors.white,
              textColor: Colors.black,
              fontSize: 16.0);
        }
      } catch (e) {
        if (mounted) {
          setState(() {
            isLogging = false;
          });
        }
      }
    } else {
      await Auth().googleLogin();
      registerNewUser(FirebaseAuth.instance.currentUser);
    }
  }

  Future<void> registerNewUser(User user) async {
    if (userDoc != null && !userDoc.exists && userDoc.data()['id'] == null) {
      await getCurrentUser();
    }
    FirebaseFirestore.instance
        .collection('Users')
        .where("id", isEqualTo: user.uid)
        .limit(1)
        .get()
        .then((doc) async {
      if (doc.docs.length > 0) {
        await getCurrentUser();
        syncDataWithFirebase();
      } else {
        sheets.Spreadsheet create = await Auth().createSheet();
        FirebaseFirestore.instance.collection('Users').doc(user.uid).set({
          'id': user.uid,
          'email': user.email,
          'photo': user.photoURL,
          'phone': user.phoneNumber,
          'providerID': user.providerData[0].providerId,
          'providerUID': user.providerData[0].uid,
          'accessToken': googleAuth.accessToken,
          'idToken': googleAuth.idToken,
          'sheetId': create.spreadsheetId,
          'sheetURL': create.spreadsheetUrl,
          'createdAt': DateTime.now().toUtc()
        }).then((val) async {
          await getCurrentUser();
          syncDataWithFirebase();
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        height: MediaQuery.of(context).size.height,
        width: MediaQuery.of(context).size.width,
        decoration: BoxDecoration(
          gradient: LinearGradient(
              colors: [Color(0xff6200EE), Colors.blue],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                padding: EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 40.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    SizedBox(
                      width: 20.0,
                    ),
                    Text(
                      'BCR',
                      style: GoogleFonts.glegoo(
                        textStyle: TextStyle(color: Colors.white, fontSize: 20),
                      ),
                    ),
                    GestureDetector(
                      behavior: HitTestBehavior.translucent,
                      onTap: () {
                        signInOut();
                        /*Navigator.push(
                            context,
                            PageTransition(
                                type: PageTransitionType.rightToLeft,
                                child: MyAppSettings()));*/
                      },
                      child: FirebaseAuth.instance.currentUser != null
                          ? Icon(
                              Icons.logout,
                              color: Colors.white,
                              size: 30.0,
                            )
                          : SizedBox(
                              width: 20.0,
                            ),
                    )
                  ],
                ),
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Container(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        GestureDetector(
                            behavior: HitTestBehavior.translucent,
                            onTap: () async {
                              var permissions = [
                                PH.Permission.camera,
                                PH.Permission.photos,
                                PH.Permission.storage,
                                PH.Permission.microphone,
                              ];
                              try {
                                Map<PH.Permission, PH.PermissionStatus>
                                    permissionStatus =
                                    await permissions.request();
                                bool isNotGranted = false;
                                for (int i = 0;
                                    i < permissionStatus.length;
                                    i++) {
                                  if (permissionStatus[permissions[i]]
                                      .isGranted) {
                                  } else {
                                    isNotGranted = true;
                                    break;
                                  }
                                }
                                if (!isNotGranted) {
                                  showDialog(
                                      context: context,
                                      builder: (context) => CameraView(false,
                                          onCardSave: () => setState(
                                                () => onCardSaved = 0,
                                              )));
                                } else {
                                  Fluttertoast.showToast(
                                      msg: "All permissions are required",
                                      toastLength: Toast.LENGTH_LONG,
                                      gravity: ToastGravity.CENTER,
                                      timeInSecForIosWeb: 1,
                                      backgroundColor: Colors.white,
                                      textColor: Colors.black,
                                      fontSize: 16.0);
                                  PH.openAppSettings();
                                }
                              } catch (e) {
                                print(e);
                              }
                            },
                            child: Container(
                              height: 180,
                              width: 180,
                              decoration: BoxDecoration(
                                  gradient: LinearGradient(
                                    colors: [
                                      Colors.blue,
                                      Colors.blueGrey,
                                    ],
                                    begin: Alignment.centerLeft,
                                    end: Alignment.centerRight,
                                  ),
                                  borderRadius: const BorderRadius.all(
                                    Radius.circular(90.0),
                                  ),
                                  boxShadow: [
                                    BoxShadow(
                                      color: Colors.black.withOpacity(0.4),
                                      spreadRadius: 4,
                                      blurRadius: 10,
                                      offset: Offset(0, 3),
                                    )
                                  ]),
                              child: Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.camera_alt_outlined,
                                      color: Colors.white,
                                      size: 50.0,
                                    ),
                                    Text('SCAN\n CARD',
                                        textAlign: TextAlign.center,
                                        style: GoogleFonts.glegoo(
                                          textStyle: TextStyle(
                                            color: Colors.white,
                                            fontSize: 16.0,
                                            fontFamily: "Netflix",
                                            fontWeight: FontWeight.w600,
                                          ),
                                        ))
                                  ],
                                ),
                              ),
                            )),
                        GestureDetector(
                          behavior: HitTestBehavior.translucent,
                          onTap: _handleSignIn,
                          child: Container(
                            height: 60,
                            margin: EdgeInsets.fromLTRB(15.0, 50.0, 15.0, 20.0),
                            decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.blue,
                                    Colors.blueAccent,
                                  ],
                                  begin: Alignment.centerRight,
                                  end: Alignment.centerLeft,
                                ),
                                borderRadius: const BorderRadius.all(
                                  Radius.circular(25.0),
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.4),
                                    spreadRadius: 4,
                                    blurRadius: 10,
                                    offset: Offset(0, 3),
                                  )
                                ]),
                            child: Center(
                              child: isLogging
                                  ? CircularProgressIndicator()
                                  : Text('Sync with gDrive',
                                      textAlign: TextAlign.center,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                          color: Colors.white,
                                          fontSize: 17.0,
                                          fontFamily: "Netflix",
                                          fontWeight: FontWeight.w600,
                                        ),
                                      )),
                            ),
                          ),
                        ),
                        GestureDetector(
                          behavior: HitTestBehavior.translucent,
                          onTap: () {
                            Navigator.push(
                                context,
                                PageTransition(
                                    type: PageTransitionType.rightToLeft,
                                    child: MyAllCards(cardsList)));
                          },
                          child: Container(
                            height: 60,
                            margin: EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 20.0),
                            decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  colors: [
                                    Colors.blue,
                                    Colors.blueAccent,
                                  ],
                                  begin: Alignment.centerRight,
                                  end: Alignment.centerLeft,
                                ),
                                borderRadius: const BorderRadius.all(
                                  Radius.circular(25.0),
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withOpacity(0.4),
                                    spreadRadius: 4,
                                    blurRadius: 10,
                                    offset: Offset(0, 3),
                                  )
                                ]),
                            child: Center(
                              child: Text('View Cards',
                                  textAlign: TextAlign.center,
                                  style: GoogleFonts.glegoo(
                                    textStyle: TextStyle(
                                      color: Colors.white,
                                      fontSize: 17.0,
                                      fontFamily: "Netflix",
                                      fontWeight: FontWeight.w600,
                                    ),
                                  )),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
      // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  String getDate(String dateTimeString) {
    DateFormat format = DateFormat("MM/dd/yyyy");
    final DateTime dateTime = DateTime.parse(dateTimeString);
    String formattedDate = format.format(dateTime);
    return formattedDate;
  }

  Future<sheets.Spreadsheet> createAndSaveSheet() async {
    sheets.Spreadsheet spreadsheet;
    sheets.Spreadsheet create = await Auth().createSheet();
    spreadsheet = await sheetApi.spreadsheets
        .get(create.spreadsheetId, includeGridData: true);
    await FirebaseFirestore.instance
        .collection('Users')
        .doc(userDoc.data()['id'])
        .update({
      'sheetId': create.spreadsheetId,
      'sheetURL': create.spreadsheetUrl,
      'updatedAt': DateTime.now().toUtc()
    });
    await getCurrentUser();
    return spreadsheet;
  }

  Future<sheets.Spreadsheet> getSpreadsheet() async {
    sheets.Spreadsheet spreadsheet;
    bool sheetNotFound = false;
    spreadsheet = await sheetApi.spreadsheets
        .get(userDoc.data()['sheetId'], includeGridData: true)
        .catchError((onError) async {
      sheetNotFound = true;
    });
    if (sheetNotFound) {
      spreadsheet = await createAndSaveSheet();
    } else {
      var res = await driveApi.files.get(userDoc.data()['sheetId'],
          $fields:
              "name,mimeType,trashed,parents,version,webContentLink,webViewLink,createdTime,modifiedTime,size");
      if (res.trashed) {
        spreadsheet = await createAndSaveSheet();
      }
    }
    return spreadsheet;
  }

  Future<void> syncDataWithFirebase() async {
    sheets.Spreadsheet spreadsheet = await getSpreadsheet();

    List<String> savedCards = List();
    for (int j = 1; j < spreadsheet.sheets[0].data[0].rowData.length; j++) {
      if (spreadsheet.sheets[0].data[0].rowData[j].values != null) {
        savedCards.add(
            spreadsheet.sheets[0].data[0].rowData[j].values[0].formattedValue);
        /* print(
            spreadsheet.sheets[0].data[0].rowData[j].values[0].formattedValue);*/
      }
    }
    List<sheets.RowData> listRowData = List<sheets.RowData>();
    List<CardsInfo> newCardList = List();
    if (cardsList != null) {
      newCardList = cardsList
          .where((element) => !savedCards.contains(element.idColumn))
          .toList();
    }

    for (int i = 0; i < newCardList.length; i++) {
      CardsInfo cardObject = newCardList[i];
      sheets.RowData rowData = sheets.RowData();
      rowData.values = List<sheets.CellData>();
      cardObject.toMapEx().forEach((final String key, final value) {
        sheets.CellData cellData = sheets.CellData();
        cellData.userEnteredValue = sheets.ExtendedValue();
        cellData.userEnteredValue.stringValue = value;
        rowData.values.add(cellData);
      });
      listRowData.add(rowData);
    }
    sheets.BatchUpdateSpreadsheetRequest batchUpdateSpreadsheetRequest =
        sheets.BatchUpdateSpreadsheetRequest();
    batchUpdateSpreadsheetRequest.requests = List<sheets.Request>();
    sheets.Request request = sheets.Request();

    sheets.UpdateCellsRequest cellRequest = sheets.UpdateCellsRequest();
    cellRequest.rows = listRowData;
    cellRequest.fields = "*";
    cellRequest.start = sheets.GridCoordinate();
    cellRequest.start.rowIndex = spreadsheet.sheets[0].data[0].rowData.length;

    cellRequest.start.sheetId = spreadsheet.sheets[0].properties.sheetId;
    request.updateCells = cellRequest;
    batchUpdateSpreadsheetRequest.requests.add(request);
    await sheetApi.spreadsheets
        .batchUpdate(batchUpdateSpreadsheetRequest, userDoc.data()['sheetId']);
    if (mounted) {
      setState(() {
        isLogging = false;
      });
    }
    Fluttertoast.showToast(
        msg: "Data syncing done",
        toastLength: Toast.LENGTH_LONG,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: Colors.white,
        textColor: Colors.black,
        fontSize: 16.0);
    if (cardsList != null) {
      for (int i = 0; i < cardsList.length; i++) {
        FirebaseFirestore.instance
            .collection('MyCards')
            .doc(FirebaseAuth.instance.currentUser.uid)
            .collection("Cards")
            .where("cardID", isEqualTo: cardsList[i].idColumn)
            .limit(1)
            .get()
            .then((doc) {
          if (doc.docs.length > 0) {
            FirebaseFirestore.instance
                .collection('MyCards')
                .doc(FirebaseAuth.instance.currentUser.uid)
                .collection('Cards')
                .doc(cardsList[i].idColumn)
                .update({
              'cardID': cardsList[i].idColumn,
              "name": cardsList[i].nameColumn,
              "phone": cardsList[i].phoneColumn,
              "phone2": cardsList[i].phoneColumn2,
              "email": cardsList[i].emailColumn,
              "email2": cardsList[i].emailColumn2,
              "address": cardsList[i].addressColumn,
              "web": cardsList[i].urlColumn,
              "zip": cardsList[i].zipColumn,
              "company": cardsList[i].companyColumn,
              "notes": cardsList[i] != null ? cardsList[i].noteColumn : "",
              "job": cardsList[i].jobColumn,
            });
          } else {
            uploadCardImage(cardsList[i]);
          }
        });
      }
    }
  }

  Future<void> uploadCardImage(CardsInfo cardItem) async {
    String imgName = DateTime.now().toIso8601String() + ".png";
    firebase_storage.FirebaseStorage _storage =
        firebase_storage.FirebaseStorage.instance;
    //Create a reference to the location you want to upload to in firebase
    firebase_storage.Reference reference = _storage
        .ref()
        .child("CardsImages/" + FirebaseAuth.instance.currentUser.uid)
        .child(imgName);

    //Upload the file to firebase
    reference.putFile(File(cardItem.imagePathColumn)).then((taskSnapshot) {
      taskSnapshot.ref.getDownloadURL().then((downloadUrl) {
        FirebaseFirestore.instance
            .collection('MyCards')
            .doc(FirebaseAuth.instance.currentUser.uid)
            .collection('Cards')
            .doc(cardItem.idColumn)
            .set({
          "id": DateTime.now().microsecondsSinceEpoch,
          'cardID': cardItem.idColumn,
          "name": cardItem.nameColumn,
          "phone": cardItem.phoneColumn,
          "phone2": cardItem.phoneColumn2,
          "email": cardItem.emailColumn,
          "email2": cardItem.emailColumn2,
          "address": cardItem.addressColumn,
          "web": cardItem.urlColumn,
          "zip": cardItem.zipColumn,
          "company": cardItem.companyColumn,
          "job": cardItem.jobColumn,
          "image": downloadUrl,
          "notes": cardItem.noteColumn != null ? cardItem.noteColumn : "",
          "date": cardItem.dateColumn
        });
      });
    });

    // Waits till the file is uploaded then stores the download url
  }

  void syncWithLocaleDB() async {
    QuerySnapshot querySnapshot = await FirebaseFirestore.instance
        .collection('MyCards')
        .doc(FirebaseAuth.instance.currentUser.uid)
        .collection('Cards')
        .get();
    _saveCardToLocale(querySnapshot);
  }

  Future<void> _saveCardToLocale(QuerySnapshot querySnapshot) async {
    for (int p = 0; p < querySnapshot.docs.length; p++) {
      var cardInfo = CardsInfo(
          querySnapshot.docs[p]['cardID'],
          querySnapshot.docs[p]['name'],
          querySnapshot.docs[p]['phone'],
          querySnapshot.docs[p]['email'],
          querySnapshot.docs[p]['address'],
          querySnapshot.docs[p]['web'],
          querySnapshot.docs[p]['zip'],
          querySnapshot.docs[p]['company'],
          querySnapshot.docs[p]['job'],
          querySnapshot.docs[p]['image'],
          querySnapshot.docs[p]['date'],
          querySnapshot.docs[p]['phone2'],
          querySnapshot.docs[p]['email2'],
          querySnapshot.docs[p].data().containsKey("notes")
              ? querySnapshot.docs[p]['notes']
              : "");

      int val = await db.saveCard(cardInfo);
    }
    _getSavedCardFromLocale();
  }

  Future<void> signInOut() async {
    if (FirebaseAuth.instance.currentUser != null) {
      await FirebaseAuth.instance.signOut();
      await googleSignIn.signOut();
    } else {
      await Auth().googleLogin();
    }
    if (mounted) setState(() {});
  }
}

typedef void StringCallback();
