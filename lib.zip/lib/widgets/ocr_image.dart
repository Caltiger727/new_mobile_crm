import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:math';
import 'dart:typed_data';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:phone_number/phone_number.dart';
import 'package:priti_app/data/card_data.dart';
import 'package:priti_app/data/database_helper.dart';
import 'package:priti_app/services/bc_parser.dart';
import 'package:priti_app/services/google_auth.dart';
import 'package:priti_app/widgets/home.dart';
import 'package:simple_vcard_parser/simple_vcard_parser.dart';

import '../main.dart';

class ScanOCRImage extends StatefulWidget {
  final String imagePath;
  final bool isEdited;
  final StringCallback onCardSave;
  final CardsInfo cardItem;

  ScanOCRImage(this.imagePath, this.isEdited, {this.cardItem, this.onCardSave});

  @override
  _ScanOCRImageState createState() =>
      _ScanOCRImageState(imagePath, isEdited, cardItem: cardItem);
}

class _ScanOCRImageState extends State<ScanOCRImage> {
  final String filePath;
  final bool isEdited;
  final CardsInfo cardItem;

  String recognizedText = "Loading ...";

  var nameController = TextEditingController();
  var emailController = TextEditingController();
  var mobileController = TextEditingController();
  var emailController2 = TextEditingController();
  var mobileController2 = TextEditingController();
  var webController = TextEditingController();
  var addressController = TextEditingController();
  var zipController = TextEditingController();
  var companyController = TextEditingController();
  var jobController = TextEditingController();
  var noteController = TextEditingController();
  String dateOfOcr;
  String cardID;
  int mobileLength = 0;
  int emailLength = 0;

  var db = DatabaseHelper();
  bool isLoading = true;

  Timer _timer;

  _ScanOCRImageState(this.filePath, this.isEdited, {this.cardItem});

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    if (!isEdited) {
      _initializeVision();
    } else {
      isLoading = false;
      setCardValues();
    }
  }

  @override
  void dispose() {
    // TODO: implement dispose
    _timer?.cancel();
    super.dispose();
  }

  Future<void> _saveCardToLocale() async {
    //saveToLocale(filePath);

    if (isEdited) {
      dateOfOcr = cardItem.dateColumn;
      cardID = cardItem.idColumn;
    } else {
      dateOfOcr = DateTime.now().toLocal().toString();
      var rng = new Random();
      cardID = (rng.nextInt(90000000) + 10000000).toString();
    }

    var cardInfo = CardsInfo(
        cardID,
        nameController.text,
        mobileController.text,
        emailController.text,
        addressController.text,
        webController.text,
        zipController.text,
        companyController.text,
        jobController.text,
        filePath,
        dateOfOcr,
        mobileController2.text,
        emailController2.text,
        noteController.text);
    int val;
    if (isEdited) {
      val = await db.updateCard(cardInfo);
    } else {
      val = await db.saveCard(cardInfo);
    }
    if (val > 0) {
      Fluttertoast.showToast(
          msg: isEdited
              ? "Card Updated Successfully"
              : "Card Added Successfully",
          toastLength: Toast.LENGTH_LONG,
          gravity: ToastGravity.CENTER,
          timeInSecForIosWeb: 1,
          backgroundColor: Colors.white,
          textColor: Colors.black,
          fontSize: 16.0);
    }
    if (widget.onCardSave != null) widget.onCardSave();
    Navigator.of(context).pop();
  }

  void _initializeVision() async {
    String username = '8a5cbffc-4957-4f86-800e-0a497a424d48';
    String password = '4X9ZUbZHM45NGaE7bDQxzQ2j';
    String basicAuth =
        'Basic ' + base64Encode(utf8.encode('$username:$password'));
    // print(basicAuth);

    var dio = new Dio();
    dio.options.baseUrl = "https://cloud-westus.ocrsdk.com/";
    dio.options.connectTimeout = 99999;
    dio.options.receiveTimeout = 99999;
    dio.options.headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': basicAuth,
    };
    FormData formData = FormData.fromMap({
      "imageSource": await MultipartFile.fromFile(filePath),
    });
    Response responseTaskID;
    try {
      responseTaskID = await dio.post("v2/processBusinessCard", data: formData);
    } catch (e) {
      print(e);
    }

    Future.delayed(const Duration(seconds: 4), () async {
      Response responseResultURL;
      String taskID = responseTaskID.data['taskId'];
      responseResultURL = await getOcrUrl(basicAuth, taskID);
      if (responseResultURL.data['status'] == "InProgress") {
        _timer = Timer.periodic(Duration(milliseconds: 4000), (Timer t) async {
          responseResultURL = await getOcrUrl(basicAuth, taskID);
          if (responseResultURL.data['status'] == "InProgress") {
          } else {
            _timer.cancel();
            setAbbyyVCData(responseResultURL);
          }
        });
      } else {
        setAbbyyVCData(responseResultURL);
      }
    });

    /*try {
      IM.Image imageToUse;
      final File imageFile = File(filePath);
      var imageBytes = await imageFile.readAsBytes();
      Map<String, IfdTag> data = await readExifFromBytes(imageBytes);
      print(data);
      Uint8List bytes = imageBytes;
      imageToUse = IM.decodeImage(bytes);
     */ /* if (data != null && data.containsKey('Image Orientation')) {
        if (data['Image Orientation'].printable.contains("Rotated 90 CW")) {
          imageToUse = IM.copyRotate(imageToUse, 90);
          File(filePath).writeAsBytesSync(IM.encodeJpg(imageToUse));
        } else if (data['Image Orientation']
            .printable
            .contains("Rotated 90 CCW")) {
          imageToUse = IM.copyRotate(imageToUse, -90);
          File(filePath).writeAsBytesSync(IM.encodeJpg(imageToUse));
        }
      }*/ /*

      if (imageFile != null) {
        var watch = Stopwatch()..start();
        String _extractText =
            await TesseractOcr.extractText(imageFile.path, language: "eng");
        int _scanTime = watch.elapsedMilliseconds;
        print(_extractText);

        List<String> _extractTextList = _extractText.split("\n");

        for (String block in _extractTextList) {
          bool nameMatch = BCParseRegex().namePattern.hasMatch(block);
          if (nameMatch) {
            nameController.text = block;
            break;
          }
        }
        for (String block in _extractTextList) {
          // print(block);
          bool urlMatch = BCParseRegex().urlPattern.hasMatch(block);
          if (urlMatch) {
            if (Fzregex.hasMatch(block, FzPattern.url)) {
              webController.text = block;
              break;
            }
          }
        }
        var emailMatch =
            BCParseRegex().emailPattern.allMatches(_extractText).map((m) {
          return m.group(0);
        });
        if (emailMatch.length > 0) {
          emailController.text = emailMatch.first;
        }

        var phoneMatch =
            BCParseRegex().phonePattern.allMatches(_extractText).map((m) {
          return m.group(0);
        });

        if (phoneMatch.length > 0) {
          mobileController.text = phoneMatch.first;
        }
        var urlMatch =
            BCParseRegex().urlPattern.allMatches(_extractText).map((m) {
          m.group(0);
        });
        if (urlMatch.length > 0) {
          webController.text = urlMatch.first;
        }
         for (String block in _extractTextList) {
          print(block);

          bool val = BCParseRegex().checkZipCode(block);
          print(val);
        }

        if (this.mounted) {
          setState(() {
            // recognizedText = mailAddress;
          });
        }
      }
    } catch (e) {
      print(e.toString());
    }*/
  }

  Future<Response> getOcrUrl(String basicAuth, String taskID) async {
    var dio = new Dio();
    dio.options.baseUrl = "https://cloud-westus.ocrsdk.com/";
    dio.options.connectTimeout = 99999;
    dio.options.receiveTimeout = 99999;
    dio.options.headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Authorization': basicAuth,
    };
    try {
      return await dio.get("v2/getTaskStatus?taskId=$taskID");
    } catch (e) {
      print(e);
    }
  }

  void setAbbyyVCData(Response<dynamic> responseResultURL) async {
    var dio = new Dio();
    dio.options.baseUrl = "https://cloud-westus.ocrsdk.com/";
    dio.options.connectTimeout = 99999;
    dio.options.receiveTimeout = 99999;
    dio.options.headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
    };

    //print(responseResultURL.data);

    Response responseResult;
    try {
      String resultURL = responseResultURL.data['resultUrls'][0];
      responseResult = await dio.get(resultURL);
    } catch (e) {
      print(e);
    }

    try {
      VCard vc = VCard(responseResult.data);
      // print(vc);
      try {
        nameController.text = vc.formattedName;
      } catch (e) {
        print(e);
      }
      try {
        companyController.text = vc.organisation;
      } catch (e) {
        print(e);
      }
      try {
        jobController.text = vc.title;
      } catch (e) {
        print(e);
      }
      try {
        noteController.text = vc.note;
      } catch (e) {
        print(e);
      }
      mobileLength = vc.typedTelephone.length;
      for (int tel = 0; tel < vc.typedTelephone.length; tel++) {
        if (tel == 0)
          mobileController.text =
              await getFormattedPhoneNumber(vc.typedTelephone[tel][0]);
        else if (tel == 1)
          mobileController2.text =
              await getFormattedPhoneNumber(vc.typedTelephone[tel][0]);
      }

      emailLength = vc.typedEmail.length;
      for (int mail = 0; mail < vc.typedEmail.length; mail++) {
        if (mail == 0)
          emailController.text = vc.typedEmail[mail][0];
        else if (mail == 1) emailController2.text = vc.typedEmail[mail][0];
      }
      String address = "";
      for (int ads = 0; ads < vc.typedAddress.length; ads++) {
        var addressList = vc.typedAddress[ads][0];

        for (int j = 0; j < addressList.length; j++) {
          address = address + " " + addressList[j];
        }
        addressController.text = address;
      }
      for (int web = 0; web < vc.typedURL.length; web++) {
        webController.text = vc.typedURL[web][0];
      }

      Map<String, dynamic> result = BCParseRegex().checkZipCode(address);
      if (result['isZip'] == true || result['isZip'] == "true") {
        zipController.text = result['zipCode'];
      }
      if (mounted)
        setState(() {
          isLoading = false;
        });
    } catch (e) {
      if (mounted)
        setState(() {
          isLoading = false;
        });
    }
  }

  Future<String> getFormattedPhoneNumber(String phone) async {
    phone = phone.replaceAll(" ", "");
    if (phone.contains("(")) {
      phone = phone.replaceAll("(", "");
    }
    if (phone.contains(")")) {
      phone = phone.replaceAll(")", "");
    }
    if (phone.length == 10) {
      return phoneFormat(phone);
    } else if (phone.contains("+")) {
      PhoneNumber _plugin = PhoneNumber();
      var parsed;
      try {
        parsed = await _plugin.parse(phone);
      } on PlatformException catch (numberExp) {
        return phone;
      }
      String countryCode = parsed['country_code'];
      String phoneNumber;
      if (countryCode != null && countryCode != "") {
        countryCode = "+" + countryCode;
        phoneNumber = phone.substring(countryCode.length, phone.length);
        phoneNumber = phoneFormat(phoneNumber);
      }
      return countryCode + "-" + phoneNumber;
    } else {
      if (phone.length > 10) {
        return phoneFormat(phone);
      } else {
        return phone;
      }
    }
  }

  String phoneFormat(String phone) {
    String formattedPhoneNumber = "(" +
        phone.substring(0, 3) +
        ") " +
        phone.substring(3, 6) +
        "-" +
        phone.substring(6, phone.length);
    return formattedPhoneNumber;
  }

  void setCardValues() {
    nameController.text = cardItem.nameColumn;
    mobileController.text = cardItem.phoneColumn;
    emailController.text = cardItem.emailColumn;
    mobileController2.text = cardItem.phoneColumn2;
    emailController2.text = cardItem.emailColumn2;
    addressController.text = cardItem.addressColumn;
    webController.text = cardItem.urlColumn;
    zipController.text = cardItem.zipColumn;
    companyController.text = cardItem.companyColumn;
    jobController.text = cardItem.jobColumn;
    noteController.text =
        cardItem.noteColumn != null ? cardItem.noteColumn : "";
    if (mobileController2.text.length > 0) mobileLength = 2;
    if (emailController2.text.length > 0) emailLength = 2;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      color: Colors.white,
      child: SafeArea(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Container(
              padding: EdgeInsets.fromLTRB(15.0, 10.0, 15.0, 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    behavior: HitTestBehavior.translucent,
                    onTap: () => Navigator.of(context).pop(),
                    child: Icon(
                      Icons.arrow_back,
                      color: Colors.black,
                    ),
                  ),
                  Text(
                    'Add Cards',
                    style: GoogleFonts.glegoo(
                      textStyle: TextStyle(color: Colors.black, fontSize: 20),
                    ),
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        behavior: HitTestBehavior.translucent,
                        onTap: () {
                          _saveCardToLocale();
                          // _handleSignIn();
                        },
                        child: Icon(
                          Icons.add,
                          color: Colors.black,
                          size: 30.0,
                        ),
                      )
                    ],
                  )
                ],
              ),
            ),
            isLoading
                ? Center(
                    child: CircularProgressIndicator(
                      backgroundColor: Colors.blue,
                    ),
                  )
                : Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Text(
                                    'Name',
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 18),
                                    ),
                                  ),
                                ),
                                Flexible(
                                    flex: 2,
                                    child: TextField(
                                      keyboardType: TextInputType.text,
                                      controller: nameController,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      ),
                                      decoration: const InputDecoration(
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black,
                                                width: 1.0),
                                          ),
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black26,
                                                width: 1.0),
                                          ),
                                          hintText: "Name",
                                          hintStyle:
                                              TextStyle(color: Colors.black26)),
                                    ))
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Text(
                                    'Email',
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 18),
                                    ),
                                  ),
                                ),
                                Flexible(
                                    flex: 2,
                                    child: TextField(
                                      controller: emailController,
                                      keyboardType: TextInputType.emailAddress,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      ),
                                      decoration: const InputDecoration(
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black,
                                                width: 1.0),
                                          ),
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black26,
                                                width: 1.0),
                                          ),
                                          hintText: "Email",
                                          hintStyle:
                                              TextStyle(color: Colors.black26)),
                                    ))
                              ],
                            ),
                          ),
                          emailLength > 1
                              ? Container(
                                  padding: EdgeInsets.fromLTRB(
                                      15.0, 0.0, 15.0, 10.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Flexible(
                                        flex: 1,
                                        child: Text(
                                          'Email',
                                          style: GoogleFonts.glegoo(
                                            textStyle: TextStyle(
                                                color: Colors.black,
                                                fontSize: 18),
                                          ),
                                        ),
                                      ),
                                      Flexible(
                                          flex: 2,
                                          child: TextField(
                                            controller: emailController2,
                                            keyboardType:
                                                TextInputType.emailAddress,
                                            style: GoogleFonts.glegoo(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 18),
                                            ),
                                            decoration: const InputDecoration(
                                                focusedBorder:
                                                    UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                      color: Colors.black,
                                                      width: 1.0),
                                                ),
                                                enabledBorder:
                                                    UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                      color: Colors.black26,
                                                      width: 1.0),
                                                ),
                                                hintText: "Email",
                                                hintStyle: TextStyle(
                                                    color: Colors.black26)),
                                          ))
                                    ],
                                  ),
                                )
                              : SizedBox(),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Text(
                                    'Mobile',
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 18),
                                    ),
                                  ),
                                ),
                                Flexible(
                                    flex: 2,
                                    child: TextField(
                                      controller: mobileController,
                                      keyboardType: TextInputType.phone,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      ),
                                      decoration: const InputDecoration(
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black,
                                                width: 1.0),
                                          ),
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black26,
                                                width: 1.0),
                                          ),
                                          hintText: "mobile",
                                          hintStyle:
                                              TextStyle(color: Colors.black26)),
                                    ))
                              ],
                            ),
                          ),
                          mobileLength > 1
                              ? Container(
                                  padding: EdgeInsets.fromLTRB(
                                      15.0, 0.0, 15.0, 10.0),
                                  child: Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceBetween,
                                    children: [
                                      Flexible(
                                        flex: 1,
                                        child: Text(
                                          'Mobile',
                                          style: GoogleFonts.glegoo(
                                            textStyle: TextStyle(
                                                color: Colors.black,
                                                fontSize: 18),
                                          ),
                                        ),
                                      ),
                                      Flexible(
                                          flex: 2,
                                          child: TextField(
                                            controller: mobileController2,
                                            keyboardType: TextInputType.phone,
                                            style: GoogleFonts.glegoo(
                                              textStyle: TextStyle(
                                                  color: Colors.black,
                                                  fontSize: 18),
                                            ),
                                            decoration: const InputDecoration(
                                                focusedBorder:
                                                    UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                      color: Colors.black,
                                                      width: 1.0),
                                                ),
                                                enabledBorder:
                                                    UnderlineInputBorder(
                                                  borderSide: BorderSide(
                                                      color: Colors.black26,
                                                      width: 1.0),
                                                ),
                                                hintText: "mobile",
                                                hintStyle: TextStyle(
                                                    color: Colors.black26)),
                                          ))
                                    ],
                                  ),
                                )
                              : SizedBox(),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Text(
                                    'Web',
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 18),
                                    ),
                                  ),
                                ),
                                Flexible(
                                    flex: 2,
                                    child: TextField(
                                      controller: webController,
                                      keyboardType: TextInputType.url,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      ),
                                      decoration: const InputDecoration(
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black,
                                                width: 1.0),
                                          ),
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black26,
                                                width: 1.0),
                                          ),
                                          hintText: "Website",
                                          hintStyle:
                                              TextStyle(color: Colors.black26)),
                                    ))
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Text(
                                    'Address',
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 18),
                                    ),
                                  ),
                                ),
                                Flexible(
                                    flex: 2,
                                    child: TextField(
                                      controller: addressController,
                                      keyboardType: TextInputType.streetAddress,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      ),
                                      decoration: const InputDecoration(
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black,
                                                width: 1.0),
                                          ),
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black26,
                                                width: 1.0),
                                          ),
                                          hintText: "Address",
                                          hintStyle:
                                              TextStyle(color: Colors.black26)),
                                    ))
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Text(
                                    'Zip',
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 18),
                                    ),
                                  ),
                                ),
                                Flexible(
                                    flex: 2,
                                    child: TextField(
                                      controller: zipController,
                                      keyboardType: TextInputType.text,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      ),
                                      decoration: const InputDecoration(
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black,
                                                width: 1.0),
                                          ),
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black26,
                                                width: 1.0),
                                          ),
                                          hintText: "Zip",
                                          hintStyle:
                                              TextStyle(color: Colors.black26)),
                                    ))
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Text(
                                    'Company',
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 18),
                                    ),
                                  ),
                                ),
                                Flexible(
                                    flex: 2,
                                    child: TextField(
                                      controller: companyController,
                                      keyboardType: TextInputType.text,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      ),
                                      decoration: const InputDecoration(
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black,
                                                width: 1.0),
                                          ),
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black26,
                                                width: 1.0),
                                          ),
                                          hintText: "Company",
                                          hintStyle:
                                              TextStyle(color: Colors.black26)),
                                    ))
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Text(
                                    'Job Title',
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 18),
                                    ),
                                  ),
                                ),
                                Flexible(
                                    flex: 2,
                                    child: TextField(
                                      controller: jobController,
                                      keyboardType: TextInputType.text,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      ),
                                      decoration: const InputDecoration(
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black,
                                                width: 1.0),
                                          ),
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black26,
                                                width: 1.0),
                                          ),
                                          hintText: "Job Title",
                                          hintStyle:
                                              TextStyle(color: Colors.black26)),
                                    ))
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.fromLTRB(15.0, 0.0, 15.0, 10.0),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Flexible(
                                  flex: 1,
                                  child: Text(
                                    'Notes',
                                    style: GoogleFonts.glegoo(
                                      textStyle: TextStyle(
                                          color: Colors.black, fontSize: 18),
                                    ),
                                  ),
                                ),
                                Flexible(
                                    flex: 2,
                                    child: TextField(
                                      controller: noteController,
                                      keyboardType: TextInputType.text,
                                      style: GoogleFonts.glegoo(
                                        textStyle: TextStyle(
                                            color: Colors.black, fontSize: 18),
                                      ),
                                      decoration: const InputDecoration(
                                          focusedBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black,
                                                width: 1.0),
                                          ),
                                          enabledBorder: UnderlineInputBorder(
                                            borderSide: BorderSide(
                                                color: Colors.black26,
                                                width: 1.0),
                                          ),
                                          hintText: "Add Notes",
                                          hintStyle:
                                              TextStyle(color: Colors.black26)),
                                    ))
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
          ],
        ),
      ),
    ));
  }
}
