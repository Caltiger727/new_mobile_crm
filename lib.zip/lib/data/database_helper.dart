import 'dart:io';
import 'dart:math';

import 'package:priti_app/data/card_data.dart';
import 'package:sqflite/sqflite.dart';
import 'dart:async';
import 'dart:io' as io;
import 'package:path_provider/path_provider.dart';
import 'package:path/path.dart' as p;

class DatabaseHelper {
  static final DatabaseHelper _instance = new DatabaseHelper.internal();

  factory DatabaseHelper() => _instance;

  static Database _db;

  final String dbName = "main.db";
  final int dbVersion = 3;
  final String tableName = "SaveContact";

  final String idColumn = "id";
  final String nameColumn = "name";
  final String phoneColumn = "phone";
  final String emailColumn = "email";
  final String addressColumn = "address";
  final String urlColumn = "web";
  final String zipColumn = "zip";
  final String companyColumn = "company";
  final String jobColumn = "job";
  final String imagePathColumn = "image";
  final String dateColumn = "date";
  final String phoneColumn2 = "phone2";
  final String emailColumn2 = "email2";
  final String noteColumn = "notes";

  Future<Database> get db async {
    if (_db != null) {
      return _db;
    }

    _db = await initDb();
    return _db;
  }

  DatabaseHelper.internal();

  initDb() async {
    io.Directory documentDirectory = await getApplicationDocumentsDirectory();
    String path = p.join(documentDirectory.path, dbName);
    var ourDb = await openDatabase(path,
        version: dbVersion, onCreate: _onCreate, onUpgrade: _onUpgrade);
    return ourDb;
  }

  void _onCreate(Database db, int version) async {
    await db.execute(
        "CREATE TABLE IF NOT EXISTS $tableName($idColumn TEXT PRIMARY KEY, $nameColumn TEXT, $emailColumn TEXT, $emailColumn2 TEXT, $phoneColumn TEXT, $phoneColumn2 TEXT, $addressColumn TEXT, $urlColumn TEXT, $zipColumn TEXT, $companyColumn TEXT, $jobColumn TEXT, $imagePathColumn TEXT, $dateColumn TEXT, $noteColumn TEXT)");
  }

  // UPGRADE DATABASE TABLES
  void _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion < newVersion) {
      await db.execute("DROP TABLE IF EXISTS $tableName");
      _onCreate(db, newVersion);
    }
  }

  //insertion
  Future<int> saveCard(CardsInfo card) async {
    Map<String, dynamic> values = new Map();
    var _results = {
      idColumn: card.idColumn,
      nameColumn: card.nameColumn,
      phoneColumn: card.phoneColumn,
      phoneColumn2: card.phoneColumn2,
      emailColumn: card.emailColumn,
      emailColumn2: card.emailColumn2,
      addressColumn: card.addressColumn,
      urlColumn: card.urlColumn,
      zipColumn: card.zipColumn,
      companyColumn: card.companyColumn,
      jobColumn: card.jobColumn,
      imagePathColumn: card.imagePathColumn,
      dateColumn: card.dateColumn,
      noteColumn: card.noteColumn
    };
    values.addAll(_results);
    var dbClient = await db;
    int res = -1;
    try {
      res = await dbClient.insert(tableName, values);
    } catch (e) {
      return res;
    }
    return res;
  }

  //get  (https://www.tutorialspoint.com/flutter/flutter_database_concepts.htm)
  Future<List<CardsInfo>> getAllCards() async {
    var dbClient = await db;
    List<Map> results = await dbClient.query(
      tableName,
      columns: CardsInfo.columns,
      orderBy: "$nameColumn ASC",
    );
    if (results.length > 0) {
      List<CardsInfo> cards = new List();
      results.forEach((result) {
        CardsInfo card = CardsInfo.fromMap(result);
        cards.add(card);
      });
      return cards;
    }
    return null;
  }

  //update

  Future<int> updateCard(CardsInfo card) async {
    var dbClient = await db;
    Map<String, dynamic> values = new Map();
    var _results = {
      nameColumn: card.nameColumn,
      phoneColumn: card.phoneColumn,
      phoneColumn2: card.phoneColumn2,
      emailColumn: card.emailColumn,
      emailColumn2: card.emailColumn2,
      addressColumn: card.addressColumn,
      urlColumn: card.urlColumn,
      zipColumn: card.zipColumn,
      companyColumn: card.companyColumn,
      jobColumn: card.jobColumn,
      noteColumn: card.noteColumn
    };
    values.addAll(_results);
    int res = await dbClient.update(tableName, values,
        where: '$idColumn = ?', whereArgs: [card.idColumn]);
    return res;
  }

//delete
  Future<int> deletePath(String id) async {
    var dbClient = await db;
    int res = await dbClient
        .delete(tableName, where: '$idColumn = ?', whereArgs: [id]);
    return res;
  }
}
