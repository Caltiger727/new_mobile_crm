class CardsInfo {
  final String idColumn;
  final String nameColumn;
  final String phoneColumn;
  final String emailColumn;
  final String addressColumn;
  final String urlColumn;
  final String zipColumn;
  final String companyColumn;
  final String jobColumn;
  final String imagePathColumn;
  final String dateColumn;
  final String phoneColumn2;
  final String emailColumn2;
  final String noteColumn;

  static final columns = [
    "id",
    "name",
    "phone",
    "phone2",
    "email",
    "email2",
    "address",
    "web",
    "zip",
    "company",
    "job",
    "image",
    "date",
    'notes'
  ];

  CardsInfo(
      this.idColumn,
      this.nameColumn,
      this.phoneColumn,
      this.emailColumn,
      this.addressColumn,
      this.urlColumn,
      this.zipColumn,
      this.companyColumn,
      this.jobColumn,
      this.imagePathColumn,
      this.dateColumn,
      this.phoneColumn2,
      this.emailColumn2,
      this.noteColumn);

  factory CardsInfo.fromMap(Map<String, dynamic> data) {
    return CardsInfo(
        data["id"],
        data["name"],
        data["phone"],
        data["email"],
        data["address"],
        data["web"],
        data["zip"],
        data["company"],
        data["job"],
        data["image"],
        data["date"],
        data['phone2'],
        data['email2'],
        data['notes'] != null ? data['notes'] : "");
  }

  Map<String, dynamic> toMap() => {
        "id": idColumn,
        "name": nameColumn,
        "phone": phoneColumn,
        "email": emailColumn,
        "address": addressColumn,
        "web": urlColumn,
        "zip": zipColumn,
        "company": companyColumn,
        "job": jobColumn,
        "image": imagePathColumn,
        "date": dateColumn,
        "phone2": phoneColumn2,
        "email2": emailColumn2,
        "notes": noteColumn != null ? noteColumn : ""
      };

  Map<String, dynamic> toMapEx() => {
        "id": idColumn,
        "name": nameColumn,
        "phone": phoneColumn,
        "phone2": phoneColumn2,
        "email": emailColumn,
        "email2": emailColumn2,
        "address": addressColumn,
        "web": urlColumn,
        "zip": zipColumn,
        "company": companyColumn,
        "job": jobColumn,
        "date": dateColumn,
        "note": noteColumn != null ? noteColumn : ""
      };
}
